package test;

import main.ApplicationConstants;
import main.controller.Main;
import main.message.Message1;
import main.message.Message2;
import main.message.Message3;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/* Remove the Setup method, ByteArrayOutputStrem Initialisation and below two lines then you can see detailed report on console
        String expectedOutput  = "Adjustment of price 10,operationAddFor ====Product :Apple ==== No. of Sale:1 ==== Adjusted Price:20";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
        */
public class TotalSaleAndPriceTest {

    ByteArrayOutputStream messages = new ByteArrayOutputStream();

    @Before
    public void setup() {
        System.setOut(new PrintStream(messages));
    }

    /*
    This Test case show the 2 report of Product/Sale/Quantity as we are Processign 20 messages
    1st Report shows the Total Apple and guava and there price based on non adjustment sale price as message 3 is 10th price
    2nd Report shows the Total Apple and guava and there price based on adjustment sale price
    (1st 7 message of Apple have non adjustment price i.e 20 and last 8 messages of Apple have adjustable price i.e. 30)
     */
    @Test
    public void testCalculateTotalPrice_givenPriceAdjustmentMessage_whenPriceComputed_ThenAdjustmentApply()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Message3 message3=new Message3("Apple",10, ApplicationConstants.ADD);
        Main main=new Main();
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message3);

        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        String expectedOutput  = "Product :guava ==== No. of Sale:20 ==== Total Sale Price:800";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
    }

     /*
    This Test case show the 2 report of Product/Sale/Quantity as we are Processign 20 messages
    1st Report shows the Total Apple and guava and there price based on non adjustment sale price as message 3 is 10th price
    2nd Report shows the Total Apple and guava and there price based on adjustment sale price
    (1st 7 message of Apple have non adjustment price i.e 20 ,
      last 8 messages of Apple have adjustable price i.e. 30,
      1st 2 message of Apple have non adjustment price i.e 40 ,
      last 2 messages of Apple have adjustable price i.e. 50,)
     */

    @Test
    public void testCalculateTotalPrice_givenTwoPriceAdjustmentMessage_whenPriceComputed_ThenAdjustmentApply()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Message3 message3=new Message3("Apple",10, ApplicationConstants.ADD);
        Message3 message4=new Message3("guava",10, ApplicationConstants.ADD);
        Main main=new Main();
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message3);

        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message4);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        String expectedOutput  = "Product :guava ==== No. of Sale:20 ==== Total Sale Price:900";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
    }

    /*
    This Test case show the 2 report of Product/Sale/Quantity as we are Processign 20 messages
    1st Report shows the Total Apple and guava and there price based on non adjustment sale price
    1st Report also shows the Total Apple and guava and there price based on non adjustment sale price
    */

    @Test
    public void testCalculateTotalPrice_givenNoPriceAdjustmentMessage_whenPriceComputed_ThenAdjustmentApply()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Main main=new Main();
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message2);

        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message2);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message);
        main.processingMessage(message2);
        main.processingMessage(message);
        String expectedOutput  = "Product :guava ==== No. of Sale:30 ==== Total Sale Price:1200";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
    }
}
