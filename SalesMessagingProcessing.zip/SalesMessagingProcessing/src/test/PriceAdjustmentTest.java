package test;

import main.ApplicationConstants;
import main.controller.Main;
import main.message.Message1;
import main.message.Message2;
import main.message.Message3;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
/* Remove the Setup method, ByteArrayOutputStrem Initialisation and below two lines then you can see detailed report on console
        String expectedOutput  = "Adjustment of price 10,operationAddFor ====Product :Apple ==== No. of Sale:1 ==== Adjusted Price:20";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
        */


public class PriceAdjustmentTest {
      ByteArrayOutputStream messages = new ByteArrayOutputStream();

    @Before
    public void setup() {
        System.setOut(new PrintStream(messages));
    }

    // This class shows the Detailed report of Adjsutment --show which product is adjusted and which sale has adjusted price
    // and which does not, it also shows when price is adjusted
    @Test
    public void testCalculateAdjustment_givenAdjustmentMessageWithAdd_WhenfiftyMessagesPlayed()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Message3 message3=new Message3("Apple",10, ApplicationConstants.ADD);
        Main main=new Main();

        for(int i=0;i<13;i++)
        {
            main.processingMessage(message);
        }
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message2);
        }
        main.processingMessage(message3);
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message);
        }
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message2);
        }
       String expectedOutput  = "Adjustment of price 10,operationAddFor ====Product :Apple ==== No. of Sale:1 ==== Adjusted Price:20";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
    }

    @Test
    public void testCalculateAdjustment_givenNoAdjustmentMessage_WhenfiftyMessagesPlayed()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Message3 message3=new Message3("Apple",10, ApplicationConstants.ADD);
        Main main=new Main();

        for(int i=0;i<25;i++)
        {
            main.processingMessage(message);
        }
        for(int i=0;i<25;i++)
        {
            main.processingMessage(message2);
        }
        String expectedOutput  = "Adjustment of price 10,operationAddFor ====Product :Apple";
        Assert.assertFalse(messages.toString().contains(expectedOutput));
    }

    @Test
    public void testCalculateAdjustment_givenAdjustmentMessageWithSubtract_WhenfiftyMessagesPlayed()
    {
        Message1 message=new Message1("Apple",20);
        Message2 message2=new Message2("guava",5,40);
        Message3 message3=new Message3("Apple",10, ApplicationConstants.SUBTRACT);
        Main main=new Main();

        for(int i=0;i<13;i++)
        {
            main.processingMessage(message);
        }
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message2);
        }
        main.processingMessage(message3);
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message);
        }
        for(int i=0;i<13;i++)
        {
            main.processingMessage(message2);
        }
       String expectedOutput  = "Adjustment of price 10,operationSubtractFor ====Product :Apple ==== No. of Sale:1 ==== Adjusted Price:20";
        Assert.assertTrue(messages.toString().contains(expectedOutput));
    }
}
