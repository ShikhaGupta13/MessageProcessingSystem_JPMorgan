package main.controller;

import main.ApplicationConstants;
import main.Recorder.MessageRecorder;
import main.ReportLogger.ReportLogger;

import java.util.ArrayList;
import java.util.List;


public class ProcessingMessage {

    ReportLogger reportLogger=new ReportLogger();
    List<MessageRecorder> messageRecorder=new ArrayList<MessageRecorder>();
    List<MessageRecorder> messageRecorderForTenMessages=new ArrayList<MessageRecorder>();
    List<MessageRecorder> messageRecorderForFiftyMessages=new ArrayList<MessageRecorder>();
    int messageNumber=1;

    /*Processing the Message: This Function do below Task
     -Calling method for Saving Message into list of class MessageRecorder
     -Increment the messageNumber to see number of message getting processed
     -Calling method for Create Report after 10 and 50 messages as required*/
    public void processMessages(String messageType,String product,int sale,int noOfSale,
                                String adjustmentOperation,int operationValue){

        saveMessagesInMessageRecorder(messageType,product,sale,noOfSale,adjustmentOperation,operationValue);
        reportLoggingOfMessages(messageNumber);
        messageNumber++;
    }

    /*Creating the Report as per requirement After 10 and 50 Messages*/
    private void reportLoggingOfMessages(int messageNumber){
        try {
            if (messageNumber % 10 == 0) {
                reportLogger.createReportSalesOfEachProductAndTotalValue(messageRecorderForTenMessages);
                messageRecorderForTenMessages.clear();
            }
            if (messageNumber % 50 == 0) {
                reportLogger.createReportofAdjustmentForLastFiftyMessages(messageRecorderForFiftyMessages);
                messageRecorderForFiftyMessages.clear();
            }
        }
        catch(Exception e){
            System.out.println("Logging Report Fail");
        }
    }

    /*Save Message In the List of Message Recorder Class. It will take care of below checks:
     --Save the Adjustment Messages for applying it to future Sales
     --Compute the Sale Price based on Adjustment if it exist for product

     messageRecorderForTenMessages is to save  latest 10 messages so that we need not to do compute total price each time from 1st sale
     messageRecorderForFiftyMessages is to get latest 50 sale to create adjustment report*/

    private void saveMessagesInMessageRecorder(String messageType,String product,int sale,int noOfSale,
                                              String adjustmentOperation,int operationValue){
        try {
            MessageRecorder singleMessage = new MessageRecorder();
            singleMessage.setMessageType(messageType);
            singleMessage.setProduct(product);
            // Resetting the sale value in case Adjustment is required(We have an adjustment message for this product before it)
            singleMessage.setSale(reportLogger.priceAfterAdjustment(sale, messageType, product));
            singleMessage.setQuantity(noOfSale);
            singleMessage.setAdjustmentOperation(adjustmentOperation);
            singleMessage.setOperationValue(operationValue);
            messageRecorder.add(singleMessage);
            messageRecorderForTenMessages.add(singleMessage);
            messageRecorderForFiftyMessages.add(singleMessage);
            //Saving the adjustment message in different map so that we can apply it with each sale and also for creating report after 50 orders
            if (messageType.equalsIgnoreCase(ApplicationConstants.MESSAGE3)) {
                reportLogger.saveAdjustmentsMessages(singleMessage);
            }
        }catch(Exception e)
        {
            System.out.println("Error in Saving Messages");
        }
    }
}
