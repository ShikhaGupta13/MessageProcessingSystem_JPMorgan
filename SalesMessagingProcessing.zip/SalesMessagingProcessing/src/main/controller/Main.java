package main.controller;

import main.message.Message1;
import main.message.Message2;
import main.message.Message3;

import static main.ApplicationConstants.*;

public class Main {
    ProcessingMessage processingMessage=new ProcessingMessage();

    public static void main(String[] args) {

    }
    //Processing Message type 1 which does not have Adjustment Operation and Operation Value and no. of sale always as 1
    public void processingMessage(Message1 message)
    {
        processingMessage.processMessages(MESSAGE1,message.getProduct(),message.getSale(),1,null,0);
    }

    //Processing Message type 2 which does not have Adjustment Operation and Operation Value and no. of sale as mentioned
    public void processingMessage(Message2 message)
    {
        processingMessage.processMessages(MESSAGE2,message.getProduct(),message.getSale(),message.getNoOfsale(),null,0);
    }

    //Processing Message type 3 which does not have sale price and no. of sale
    public void processingMessage(Message3 message)
    {
        processingMessage.processMessages(MESSAGE3,message.getProduct(),0,0,
                message.getAdjustmentOperation(),message.getOperationValue());
    }

}
