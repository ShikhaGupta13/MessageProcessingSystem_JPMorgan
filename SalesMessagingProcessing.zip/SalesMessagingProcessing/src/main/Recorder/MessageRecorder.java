package main.Recorder;

public class MessageRecorder {

    private String messageType;
    private String product;
    private int sale;
    private int quantity;
    private String adjustmentOperation;
    private int operationValue;

    public MessageRecorder() {
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public int getOperationValue() {
        return operationValue;
    }

    public void setOperationValue(int operationValue) {
        this.operationValue = operationValue;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getSale() {
        return sale;
    }

    public void setSale(int sale) {
        this.sale = sale;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getAdjustmentOperation() {
        return adjustmentOperation;
    }

    public void setAdjustmentOperation(String adjustmentOperation) {
        this.adjustmentOperation = adjustmentOperation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MessageRecorder that = (MessageRecorder) o;

        if (sale != that.sale) return false;
        if (quantity != that.quantity) return false;
        if (operationValue != that.operationValue) return false;
        if (messageType != null ? !messageType.equals(that.messageType) : that.messageType != null) return false;
        if (product != null ? !product.equals(that.product) : that.product != null) return false;
        return adjustmentOperation != null ? adjustmentOperation.equals(that.adjustmentOperation) : that.adjustmentOperation == null;

    }

    @Override
    public int hashCode() {
        int result = messageType != null ? messageType.hashCode() : 0;
        result = 31 * result + (product != null ? product.hashCode() : 0);
        result = 31 * result + sale;
        result = 31 * result + quantity;
        result = 31 * result + (adjustmentOperation != null ? adjustmentOperation.hashCode() : 0);
        result = 31 * result + operationValue;
        return result;
    }
}
