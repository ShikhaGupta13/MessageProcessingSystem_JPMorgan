package main.ReportLogger;

public class TotalSaleLogger {

    private int sale;
    private int quantity;

    public TotalSaleLogger() {
    }

    public int getSale() {
        return sale;
    }

    public void setSale(int sale) {
        this.sale = sale;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TotalSaleLogger that = (TotalSaleLogger) o;

        if (sale != that.sale) return false;
        return quantity == that.quantity;

    }

    @Override
    public int hashCode() {
        int result = sale;
        result = 31 * result + quantity;
        return result;
    }
}
