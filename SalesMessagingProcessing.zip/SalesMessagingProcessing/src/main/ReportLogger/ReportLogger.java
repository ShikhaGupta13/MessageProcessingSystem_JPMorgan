package main.ReportLogger;

import main.ApplicationConstants;
import main.Recorder.MessageRecorder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportLogger {

    Map<String,TotalSaleLogger> totalSale=new HashMap<String,TotalSaleLogger>();

    Map<String,AdjustmentLogger> totalAdjustment=new HashMap<String,AdjustmentLogger>();

    /* Publish Report Regarding Total Sale,product and quantity After Every 10 Sale
    Created a hashmap to save the product and sale/quantity mapping which would be added with each new 10 set of messages
     */
    public void createReportSalesOfEachProductAndTotalValue(List<MessageRecorder> messageRecorder){
        try {
            for (MessageRecorder singleMessage : messageRecorder) {
                if (singleMessage.getMessageType() != ApplicationConstants.MESSAGE3) {
                    if (totalSale.containsKey(singleMessage.getProduct())) {
                        TotalSaleLogger totalSaleLogger = totalSale.get(singleMessage.getProduct());
                        totalSaleLogger.setQuantity(totalSaleLogger.getQuantity() + singleMessage.getQuantity());
                        totalSaleLogger.setSale(totalSaleLogger.getSale() + (singleMessage.getQuantity() * singleMessage.getSale()));
                    } else {
                        TotalSaleLogger totalSaleLogger = new TotalSaleLogger();
                        totalSaleLogger.setSale(singleMessage.getQuantity() * singleMessage.getSale());
                        totalSaleLogger.setQuantity(singleMessage.getQuantity());
                        totalSale.put(singleMessage.getProduct(), totalSaleLogger);
                    }
                }
            }
            System.out.println("---------------After Processing batch of 10 Messages Total Sale till now is:-----------");
            for (String product : totalSale.keySet()) {


                TotalSaleLogger totalSaleLogger = totalSale.get(product);
                System.out.println("Product :" + product + " ==== No. of Sale:" +
                        totalSaleLogger.getQuantity() + " ==== Total Sale Price:" + totalSaleLogger.getSale());

            }
        }
        catch(Exception e)
        {
            System.out.println("Error in Generating Total Sale Report");
        }
    }

    /*Publish Report containing the Adjustments on last 50 Messages
    Shows the Adjustment Product and the  sale of it whether old or new based on when it encountered the adjustment message
*/
    public void createReportofAdjustmentForLastFiftyMessages(List<MessageRecorder> messageRecorder){
        System.out.println("Application is Pausing for Some Time");
        try {
            for (MessageRecorder singleMessage : messageRecorder) {
                if (singleMessage.getMessageType() != ApplicationConstants.MESSAGE3) {
                    if (totalAdjustment.containsKey(singleMessage.getProduct())) {
                        AdjustmentLogger adjustmentLogger = totalAdjustment.get(singleMessage.getProduct());
                        System.out.println("Adjustment of price " + adjustmentLogger.getOperationValue() +
                                ",operation" + adjustmentLogger.getAdjustmentOperation() + "For ====Product :" +
                                singleMessage.getProduct() + " ==== No. of Sale:" +
                                singleMessage.getQuantity() + " ==== Adjusted Price:" + singleMessage.getSale());
                    } else {
                        System.out.println("No Adjustment For ==== Product :" + singleMessage.getProduct() + " ==== No. of Sale:" +
                                singleMessage.getQuantity() + " ==== Total Sale Price:" + singleMessage.getSale());
                    }
                }
            }
        }catch(Exception e)
        {
            System.out.println("Error in Generating Adjustment Report");
        }
    }

    private int getAdjustedPrice(int sale,int OperationValue,String adjustmentOperation)
    {
        if(adjustmentOperation.equalsIgnoreCase(ApplicationConstants.ADD))
        {
            sale=sale+OperationValue;
            return sale;
        }

        if(adjustmentOperation.equalsIgnoreCase(ApplicationConstants.SUBTRACT))
        {
            sale=sale-OperationValue;
            return sale;
        }

        if(adjustmentOperation.equalsIgnoreCase(ApplicationConstants.MULTIPLY))
        {
            sale=sale*OperationValue;
            return sale;
        }

        return sale;
    }
//calculate new price as per the Adjustment Message if exist on product
    public int priceAfterAdjustment(int sale,String messageType,String product) {
        if (messageType != ApplicationConstants.MESSAGE3) {
            if (totalAdjustment.containsKey(product)) {
                AdjustmentLogger adjustmentLogger = totalAdjustment.get(product);
                int adjustedPrice = getAdjustedPrice(sale,
                        adjustmentLogger.getOperationValue(), adjustmentLogger.getAdjustmentOperation());
                return adjustedPrice;
            }

        }
        return sale;
    }

    //Save the AdjustmentMessage into Different Adjustment Logger class
    public void saveAdjustmentsMessages(MessageRecorder singleMessage){
        AdjustmentLogger adjustmentLogger = new AdjustmentLogger();
        adjustmentLogger.setOperationValue(singleMessage.getOperationValue());
        adjustmentLogger.setAdjustmentOperation(singleMessage.getAdjustmentOperation());
        totalAdjustment.put(singleMessage.getProduct(), adjustmentLogger);
    }
}
