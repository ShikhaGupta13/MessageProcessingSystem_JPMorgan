package main.ReportLogger;

public class AdjustmentLogger {

    private String adjustmentOperation;
    private int operationValue;

    public AdjustmentLogger() {
    }

    public String getAdjustmentOperation() {
        return adjustmentOperation;
    }

    public void setAdjustmentOperation(String adjustmentOperation) {
        this.adjustmentOperation = adjustmentOperation;
    }

    public int getOperationValue() {
        return operationValue;
    }

    public void setOperationValue(int operationValue) {
        this.operationValue = operationValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AdjustmentLogger that = (AdjustmentLogger) o;

        if (operationValue != that.operationValue) return false;
        return adjustmentOperation != null ? adjustmentOperation.equals(that.adjustmentOperation) : that.adjustmentOperation == null;

    }

    @Override
    public int hashCode() {
        int result = adjustmentOperation != null ? adjustmentOperation.hashCode() : 0;
        result = 31 * result + operationValue;
        return result;
    }
}
