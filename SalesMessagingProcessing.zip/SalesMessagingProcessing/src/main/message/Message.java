package main.message;

public class Message {

    private String Product;

    public Message(String product) {
        Product = product;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String product) {
        Product = product;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Message message = (Message) o;

        return Product != null ? Product.equals(message.Product) : message.Product == null;

    }

    @Override
    public int hashCode() {
        return Product != null ? Product.hashCode() : 0;
    }
}
