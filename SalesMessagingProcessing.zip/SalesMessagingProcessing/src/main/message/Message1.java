package main.message;


public class Message1 extends Message {

    private int sale;

    public Message1(String product) {
        super(product);
    }

    public Message1(String product, int sale) {
        super(product);
        this.sale = sale;
    }

    public int getSale() {
        return sale;
    }

    public void setSale(int sale) {
        this.sale = sale;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Message1 message1 = (Message1) o;

        return sale == message1.sale;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + sale;
        return result;
    }
}
