package main.message;

/**
 * Created by GuptaS on 18/05/2017.
 */
public class Message2 extends Message{

    private int sale;
    private int noOfsale;

    public Message2(String product) {
        super(product);
    }

    public Message2(String product, int noOfsale, int sale) {
        super(product);
        this.noOfsale = noOfsale;
        this.sale = sale;
    }

    public int getNoOfsale() {
        return noOfsale;
    }

    public void setNoOfsale(int noOfsale) {
        this.noOfsale = noOfsale;
    }

    public int getSale() {
        return sale;
    }

    public void setSale(int sale) {
        this.sale = sale;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Message2 message2 = (Message2) o;

        if (sale != message2.sale) return false;
        return noOfsale == message2.noOfsale;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + sale;
        result = 31 * result + noOfsale;
        return result;
    }
}
