package main.message;

public class Message3 extends Message{

    private String adjustmentOperation;
    private int operationValue;

    public Message3(String product) {
        super(product);
    }

    public Message3(String product, int operationValue, String adjustmentOperation) {
        super(product);
        this.operationValue = operationValue;
        this.adjustmentOperation = adjustmentOperation;
    }

    public String getAdjustmentOperation() {
        return adjustmentOperation;
    }

    public void setAdjustmentOperation(String adjustmentOperation) {
        this.adjustmentOperation = adjustmentOperation;
    }

    public int getOperationValue() {
        return operationValue;
    }

    public void setOperationValue(int operationValue) {
        this.operationValue = operationValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Message3 message3 = (Message3) o;

        if (operationValue != message3.operationValue) return false;
        return adjustmentOperation != null ? adjustmentOperation.equals(message3.adjustmentOperation) : message3.adjustmentOperation == null;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (adjustmentOperation != null ? adjustmentOperation.hashCode() : 0);
        result = 31 * result + operationValue;
        return result;
    }
}
