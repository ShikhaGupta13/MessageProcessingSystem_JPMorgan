package main;

public final class ApplicationConstants {

    public static final String MESSAGE1="message1";
    public static final String MESSAGE2="message2";
    public static final String MESSAGE3="message3";

    public static final String ADD="Add";
    public static final String SUBTRACT="Subtract";
    public static final String MULTIPLY="Multiply";
}
